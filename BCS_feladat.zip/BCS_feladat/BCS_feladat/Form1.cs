using MySqlConnector;
using System.Windows.Forms.VisualStyles;

namespace BCS_feladat
{
    public partial class Form1 : Form
    {
        static public List<kiosztas> radios = new List<kiosztas>();
        public Form1()
        {
            InitializeComponent();
        }
        private var builder = new MySqlConnectionStringBuilder
        {
            Server = "197.116.1.0",
            UserID = "admin",
            
            Database = "radioadok",
        };


        private void Form1_Load(object sender, EventArgs e)

        {
            string[] kiosztas = File.ReadAllLines("kiosztas.txt");
            foreach (var item in kiosztas)
            {
                radios.Add(new radio(item));
            }

            string[] telepules = File.ReadAllLines("telepules.txt");
            foreach (var item in kiosztas)
            {
                radios.Add(new radio(item));
            }

            string[] regio = File.ReadAllLines("regio.txt");
            foreach (var item in kiosztas)
            {
                radios.Add(new radio(item));
            }

        }
    }
    public class kiosztas
    {
        public double frekvencia {  get; set; }
        public double teljesitmeny { get; set; }
        public string csatorna { get; set; }
        public string adohely {  get; set; }
        public string cim {  get; set; }


        public kiosztas(double frekvencia, double teljesitmeny, string csatorna, string adohely, string cim)

        {
            this.frekvencia = frekvencia;
            this.
        }

        
        
    }


}
