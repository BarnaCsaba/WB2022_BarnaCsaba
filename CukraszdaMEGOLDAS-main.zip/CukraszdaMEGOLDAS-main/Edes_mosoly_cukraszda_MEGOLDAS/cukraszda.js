//10. feladat
var uzenetKuldes = function () {
    var xmlhttp = new XMLHttpRequest();
    var nevInput = document.getElementById("name");
    var emailInput = document.getElementById("email");
    var telInput = document.getElementById("phone");
    var uzenetInput = document.getElementById("message");

    if (nevInput.value === "" || emailInput.value === "" || telInput.value === "" || uzenetInput.value === "") {
        alert("Kérjük, minden mezőt töltsön ki az űrlapon!");
        return;
    }

    xmlhttp.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            nevInput.value = "";
            emailInput.value = "";
            telInput.value = "";
            uzenetInput.value = "";
            alert("Munkatársunk hamarosan keresni fogja Önt!");
        }
    };
    xmlhttp.open('POST', '/api/uzenet');
    xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xmlhttp.send(JSON.stringify({
        name: nevInput.value,
        email: emailInput.value,
        phone: telInput.value,
        message: uzenetInput.value
    }));
};


// 11. feladat
    var szerencseGeneralas = function () {
    var szerencseHely = document.getElementById("szerencseUzenet");
    var uzenetek = 
    [ 
        "Hagyd, hogy a mosolyod megváltoztassa a világot, de ne hagyd, hogy a világ megváltoztassa a mosolyod. (Buddha)", 
        "Mindennek megvan a maga ideje. Még a mosolygásnak is. (Salla Simukka)", 
        "Mindig az az erősebb, aki nem tombol, hanem mosolyog.", 
        "A mosoly, melyet küldesz, visszatér hozzád.", 
        "A legtöbb mosolyt egy másik mosoly indította el. (Frank A. Clark)",
        "Minden könnyebben megy egy kis mosollyal. (Christina Dodd)",
        "Amikor a szeretet nem győz le mindent, akkor a sütik következnek.",
        "A nagy beszélgetésekhez elengedhetetlen a csokis keksz. (Tamara Ireland Stone)",
        "Egy igazán krémes csoki torta sokat ad sok embernek, nekem is! (Audrey Hepburn)",
        "Az élet bizonytalan. Kezdd a desszerttel! (Ernestine Ulmer)"
    ];

    var uzenetIndex = Math.floor(Math.random() * uzenetek.length);

    szerencseHely.textContent = uzenetek[uzenetIndex];
};

